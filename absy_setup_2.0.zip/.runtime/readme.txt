

 Certain portions of this software are based on source code from OpenJDK
(http://openjdk.java.net/)  and  licensed  under  the GNU General Public
License  version  2  (GPLv2)  with   the  Classpath  Exception  (http://
openjdk.java.net/legal/gplv2+ce.html).  For a period of three years from
the date  of your receipt  of  this  software,  Azul  will  provide upon
request, a complete  machine readable  copy of the  source code for such
portions  based  on  OpenJDK on a medium  customarily used  for software
interchange for a charge no more  than the cost of physically performing
source distribution.


  Please email azul_openjdk@azul.com for further information.

  Include this version code in your email:
  zsrc17.40.19-jdk17.0.6 de02745c0000ec7b3d5b434a3e1b3fadac351023
  OpenJFX 19  c6f8cd89a0b0cce8793a5d9b456cb66203721b6e
  CRS 1.0.11

To read more about Azul products visit https://www.azul.com/products/?r=zulu
